<?php

namespace ACP\Filtering\Model\CustomField;

use ACP\Filtering\Model;

class MultipleValues extends Model\Disabled {

}