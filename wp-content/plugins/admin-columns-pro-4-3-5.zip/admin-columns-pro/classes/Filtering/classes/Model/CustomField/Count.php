<?php

namespace ACP\Filtering\Model\CustomField;

use ACP\Filtering\Model;

class Count extends Model\Disabled {

}