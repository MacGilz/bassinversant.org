<?php

namespace ACP\Filtering\Model\CustomField;

use ACP\Filtering\Model;

class LibraryId extends Model\CustomField\Image {

	// @see Model_CustomField_Image

}