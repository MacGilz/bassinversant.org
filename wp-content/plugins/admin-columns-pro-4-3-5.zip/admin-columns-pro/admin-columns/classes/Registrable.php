<?php

namespace AC;

interface Registrable {

	public function register();

}