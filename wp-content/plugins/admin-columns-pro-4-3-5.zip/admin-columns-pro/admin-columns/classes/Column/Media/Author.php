<?php

namespace AC\Column\Media;

use AC\Column;

/**
 * @since 3.0
 */
class Author extends Column\Post\Author {
}