# JS directory

Use this directory to store JS files.

This directory can be removed if not used.
